package br.edu.fiec.MapeamentoDeSaude.features.search.repositories;

public interface UbsRepository {
}
