package br.edu.fiec.MapeamentoDeSaude.features.user.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import lombok.Data;

import java.util.UUID;

@Entity
@Data
public class Vacina {

    @GeneratedValue
    private UUID id;

    
}
