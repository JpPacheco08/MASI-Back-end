package br.edu.fiec.MapeamentoDeSaude.features.auth.dto;

import lombok.Data;

@Data
public class LoginResponse {
    String token;
}