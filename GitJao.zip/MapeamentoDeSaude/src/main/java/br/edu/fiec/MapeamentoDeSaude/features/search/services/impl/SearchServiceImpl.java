package br.edu.fiec.MapeamentoDeSaude.features.search.services.impl;

public class SearchServiceImpl {
}
