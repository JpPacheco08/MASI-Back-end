package br.edu.fiec.MapeamentoDeSaude.features.search.controllers;

public class SearchController {
}
