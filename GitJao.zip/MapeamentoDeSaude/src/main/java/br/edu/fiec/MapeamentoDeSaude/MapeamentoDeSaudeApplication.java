package br.edu.fiec.MapeamentoDeSaude;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapeamentoDeSaudeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapeamentoDeSaudeApplication.class, args);
	}

}
