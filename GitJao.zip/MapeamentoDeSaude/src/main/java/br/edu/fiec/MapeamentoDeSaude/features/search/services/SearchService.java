package br.edu.fiec.MapeamentoDeSaude.features.search.services;

public interface SearchService {
}
