package br.edu.fiec.MapeamentoDeSaude;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapeamentoDeSaudeApplicationTests {

	@Test
	void contextLoads() {
	}

}
